pkill python3
