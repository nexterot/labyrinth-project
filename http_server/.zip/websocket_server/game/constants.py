# -*- coding: utf-8 -*-


BOMB = 0
CONCRETE = 1
AID = 2